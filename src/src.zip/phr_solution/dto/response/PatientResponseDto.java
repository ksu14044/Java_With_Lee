package phr_solution.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class PatientResponseDto {
    private String name;
    private String gender;
}
