package chapter07.animalApp;

/*
*  Animal 클래스
*  : 모든 동물 객체의 부모 클래스
* */
public class Animal {
    void speak() {
        System.out.println("동물이 소리를 냅니다.");
    }
}
