package chapter07.animalApp;

public class Cat extends Animal {
    @Override
    void speak() {
        System.out.println("야옹");
    }
    void eat() {
        System.out.println("나는 츄르가 좋아");
    }
}
