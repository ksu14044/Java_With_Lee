package chapter07.practiceApp;

/*
* App 클래스
* - Entity 의 객체(부모1, 자식2)를 활용하는 시스템 구현
*
* */
public class App {
    public static void main(String[] args) {

    }
}
