package chapter07.practiceApp;

class 부모클래스 {

}

class 자식클래스1 {

}

class 자식클래스2 {

}

public class Entity {
}
