package chapter01;

// 1번 문제
// - 기본 데이터 타입  : 자료값 자체를 저장할 수 있는 데이터타입
// 종류로는 문자형(char), 정수형(int,short,long,byte), 실수형(double,float), 문자열(String), 논리형(boolean)등이 있다.

// - 참조 데이터 타입 : 자료가 저장되어 있는 주소의 값을 저장하는 데이터타입
// 종류로는 정수(Integer), 문자열(String), 문자형(Character),논리형(Boolean) 등이 있다.

// 6번 문제
// : Object

// 7번 문제
// : .length

// 8번 문제
// : 삼항 연산자 (조건 ? true인 경우에 실행할 실행문 : false인 경우에 실행할 실행문)

// 9번 문제
// : 3번

// 10번 문제
// : 2번

// 11번 문제
// : Child

// 12번 문제
// : 2번

// 13번 문제
// : 2번

// 14번 문제
// : dog가 animal의 하위 클래스여야 한다. / dog instanceof Animal 값이 true여야 한다.

// 15번 문제
// : 2번

// 16번 문제
// : 2번

// 17번 문제
// : public abstract

// 18번 문제
// : 3번

// 19번
// :



// 20번
// : 재밌습니다.


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Student {
    private String name;
    private int score;
    public Student(String name, int score){
        this.name = name;
        this.score = score;
    }
    public String getName(){
        return name;
    }
    public int getScore() {
        return score;
    }
}
public class Test {
    public static void main(String[] args) {
        // 2번 문제
        int num1 = 10;
        double num2 = 3.5;
        double result = num1 + num2;
        System.out.println(result);

        // 3번 문제
        Scanner sc = new Scanner(System.in);
        int userInput = sc.nextInt();
        if( userInput % 2 == 0) {
            System.out.println("입력하신 숫자는 짝수입니다.");
        } else{
            System.out.println("입력하신 숫자는 홀수입니다.");
        }
        sc.close();

        // 4번 문제
        int[] numbers = {1,2,3,4,5};
        for (int number : numbers) {
            System.out.println(number);
        }

        // 5번 문제
        Student student1 = new Student("John", 85);
        Student student2 = new Student("Jane", 92);
        Student student3 = new Student("Tom", 78);
        Student student4 = new Student("Emily", 88);
        Student student5 = new Student("Alex", 95);

        List<Student> student = new ArrayList<>();

        student.add(student1);
        student.add(student2);
        student.add(student3);
        student.add(student4);
        student.add(student5);

        for(int i = 0 ; i < student.size() ; i++) {
            if(student.get(i).getScore()>=90) {
                System.out.println(student.get(i).getName());
            }
        }

    }
}
